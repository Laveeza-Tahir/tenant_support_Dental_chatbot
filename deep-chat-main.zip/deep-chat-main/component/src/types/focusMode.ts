export type FocusModeFade = boolean | number;

export type FocusMode = boolean | {scroll?: boolean; fade?: FocusModeFade};
