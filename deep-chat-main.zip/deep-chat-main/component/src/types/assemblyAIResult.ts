export interface AssemblyAIResult {
  upload_url: string;
  error?: string;
}
