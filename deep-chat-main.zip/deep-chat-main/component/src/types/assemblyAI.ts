export interface AssemblyAI {
  audio?: true;
}
