export interface RequestBodyLimits {
  maxMessages?: number;
  totalMessagesMaxCharLength?: number;
}
