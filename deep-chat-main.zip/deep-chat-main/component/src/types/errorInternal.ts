import {Response} from './response';

export type ErrorResp = string | string[] | Error | Response;
