/* eslint-disable max-len */
// prettier-ignore
export const CUSTOM_ICON_STRING =
`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 22 22" fill="none">
  <rect x="2.5" y="2.5" width="17" height="17" rx="2" stroke="#000000" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
`;
