package com.server.utils.types;

public class StabilityAIImageResult {
  private StabilityAIImageArtifact[] artifacts;

  public StabilityAIImageArtifact[] getArtifacts() {
    return this.artifacts;
  }
}
