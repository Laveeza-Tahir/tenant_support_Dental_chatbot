package com.server.utils.types;

public class CohereSummarizeBody {
  private String text;

  public CohereSummarizeBody(String text) {
    this.text = text;
  }

  public String getText() {
    return this.text;
  }
}
