package com.server.utils.types;

public class HuggingFaceImageResultLabel {
  private String label;

  public String getLabel() {
    return this.label;
  }
}
