package com.server.utils.types;

public class StabilityAIPromptText {
  private String text;

  public StabilityAIPromptText(String text) {
    this.text = text;
  }

  public String getText() {
    return this.text;
  }
}
